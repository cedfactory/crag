import os
import shutil
import time
import pandas as pd
import numpy as np
from . import trade,rtstr,utils,traces
from .toolbox import monitoring_helper
import pika
import json
import ast
import threading
import pickle
from datetime import datetime, timedelta
from datetime import date

import matplotlib.pyplot as plt
import random
import string

# Set the random seed for reproducibility (optional)
random.seed(42)

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

# to launch crag as a rabbitmq receiver :
# > apt-get install rabbitmq-server
# > systemctl enable rabbitmq-server
# > systemctl start rabbitmq-server
# systemctl is not provided by WSL :
# > service rabbitmq-server start
# reference : https://medium.com/analytics-vidhya/how-to-use-rabbitmq-with-python-e0ccfe7fa959
class Crag:
    def __init__(self, params = None):
        self.exit = False
        self.safety_run = True
        self.broker = None
        self.rtstr = None
        self.working_directory = None
        self.interval = 1
        self.logger = None
        self.clear_unused_data = True
        self.start_date = ""
        self.end_date = ""
        self.original_portfolio_value = 0
        self.minimal_portfolio_value = 0
        self.minimal_portfolio_date = ""
        self.maximal_portfolio_value = 0
        self.minimal_portfolio_variation = 0
        self.maximal_portfolio_variation = 0
        self.previous_usdt_equity = 0
        self.maximal_portfolio_date = ""
        self.id = str(utils.get_random_id())
        self.high_volatility_sleep_duration = 0
        self.activate_volatility_sleep = False
        self.drawdown = 0
        self.actual_drawdown_percent = 0
        self.total_SL_TP = 0
        self.total_SL_TP_percent = 0
        self.monitoring = monitoring_helper.SQLMonitoring("ovh_mysql")
        self.tradetraces = traces.TradeTraces()
        self.init_grid_position = True
        self.start_time_grid_strategy = None
        self.iteration_times_grid_strategy = []
        self.average_time_grid_strategy = 0
        self.average_time_grid_strategy_overall = 0
        self.start_time_grid_strategy_init = None
        self.grid_iteration = 0

        if params:
            self.broker = params.get("broker", self.broker)
            if self.broker:
                self.original_portfolio_value = self.broker.get_portfolio_value()
                self.minimal_portfolio_value = self.original_portfolio_value
                self.maximal_portfolio_value = self.original_portfolio_value
            self.rtstr = params.get("rtstr", self.rtstr)
            self.interval = params.get("interval", self.interval)
            self.logger = params.get("logger", self.logger)
            self.working_directory = params.get("working_directory", self.working_directory)
            self.id = params.get("id", self.id)
            self.working_directory = params.get("working_directory", self.working_directory)

        self.traces_trade_total_opened = 0
        self.traces_trade_total_closed = 0
        self.traces_trade_total_remaining = 0
        if self.broker and self.broker.resume_strategy():
            self.current_trades = self.get_current_trades_from_account()
        else:
            self.current_trades = []

        self.cash = 0
        self.init_cash_value = 0
        self.portfolio_value = 0
        self.wallet_value = 0
        self.sell_performed = False
        self.epsilon_size_reduce = 0.1

        self.zero_print = True
        self.flush_current_trade = False

        if self.rtstr:
            self.strategy_name = self.rtstr.get_info()
        if self.broker:
            self.final_datetime = self.broker.get_final_datetime()
            # self.start_date, self.end_date, self.interval = self.broker.get_info()
            self.start_date, self.end_date, _ = self.broker.get_info() # CEDE To be confirmed
        self.export_filename = "sim_broker_history" + "_" + self.strategy_name + "_" + str(self.start_date) + "_" + str(self.end_date) + "_" + str(self.interval) + ".csv"
        self.backup_filename = self.id + "_crag_backup.pickle"

        if not self.working_directory:
            self.working_directory = './output/' # CEDE NOTE: output directory name to be added to .xml / output as default value

        if not os.path.exists(self.working_directory):
            os.makedirs(self.working_directory)
        else:
            shutil.rmtree(self.working_directory)
            os.makedirs(self.working_directory)
        self.export_filename = os.path.join(self.working_directory, self.export_filename)
        self.backup_filename = os.path.join(self.working_directory, self.backup_filename)

        self.temp_debug = True

        self.traces_trade_positive = 0
        self.traces_trade_negative = 0
        self.start_date_from_resumed_data = ""
        self.start_date_for_log = ""

        if self.broker and self.broker.broker_resumed():
            self.df_reboot_data = self.get_reboot_data()
            if self.df_reboot_data is not None:
                self.traces_trade_positive = self.df_reboot_data["positive trades"][0]
                self.traces_trade_negative = self.df_reboot_data["negative trades"][0]
                self.traces_trade_total_opened = self.df_reboot_data["transactions opened"][0]
                self.traces_trade_total_closed = self.df_reboot_data["closed"][0]
                self.start_date_from_resumed_data = self.df_reboot_data["original start"][0]
                self.original_portfolio_value = self.df_reboot_data["original portfolio value"][0]
                self.maximal_portfolio_value = self.df_reboot_data["max value"][0]
                self.maximal_portfolio_date = self.df_reboot_data["date max value"][0]
                self.minimal_portfolio_value = self.df_reboot_data["min value"][0]
                self.minimal_portfolio_date = self.df_reboot_data["date min value"][0]

        # rabbitmq connection
        self.send_alive_notification()

        try:
            connection = pika.BlockingConnection(pika.ConnectionParameters(host='127.0.0.1'))
            channel = connection.channel()
            channel.queue_declare(queue="StrategyMonitoring")

            def callback(ch, method, properties, bbody):
                print(" [x] Received {}".format(bbody))
                body = bbody.decode()
                body = json.loads(body)
                if body and body["id"] == "command" and body["strategy_id"] == self.rtstr.id:
                    command = body["command"]
                    if command == "stop":
                        print("stopping ", self.rtstr.id)
                        os._exit(0)

                if body == "history" or body == "stop":
                    self.export_history(self.export_filename)
                    self.log(msg="> {}".format(self.export_filename), header="{}".format(body), attachments=[self.export_filename])
                    os.remove(self.export_filename)
                    if body == "stop":
                        os._exit(0)
                elif body == "rtctrl":
                    rtctrl = self.rtstr.get_rtctrl()
                    if rtctrl:
                        summary = rtctrl.display_summary_info()
                        df_rtctrl = rtctrl.df_rtctrl
                        if isinstance(df_rtctrl, pd.DataFrame):
                            filename = str(utils.get_random_id())+"_rtctrl.csv"
                            df_rtctrl.to_csv(filename)
                            self.log(msg="> {}".format(filename), header="{}".format(body), attachments=[filename])
                            os.remove(filename)
                        else:
                            self.log("rtctrl is not a dataframe", header="{}".format(body))
                elif body == "rtctrl_summary":
                    rtctrl = self.rtstr.get_rtctrl()
                    if rtctrl:
                        summary = rtctrl.display_summary_info()
                        self.log(msg=summary, header="{}".format(body))
                else:
                    self.log(msg="> {} : unknown message".format(body))

            channel.basic_consume(queue="StrategyMonitoring", on_message_callback=callback, auto_ack=True)
            
            #channel.start_consuming()
            thread = threading.Thread(name='t', target=channel.start_consuming, args=())
            thread.setDaemon(True)
            thread.start()
        except:
            print("Problem encountered while configuring the rabbitmq receiver")


    def log(self, msg, header="", attachments=[]):
        if self.logger:
            self.logger.log(msg, header="["+self.id+"] "+header, author=type(self).__name__, attachments=attachments)

    def send_alive_notification(self):
        if self.broker and self.rtstr:
            current_datetime = datetime.now()
            current_timestamp = datetime.timestamp(current_datetime)
            self.monitoring.send_alive_notification(current_timestamp, self.broker.account.get("id"), self.rtstr.id)

    def run(self):
        self.start_date = self.broker.get_current_datetime("%Y/%m/%d %H:%M:%S")

        self.minimal_portfolio_date = self.start_date
        self.maximal_portfolio_date = self.start_date
        msg_broker_info = self.broker.log_info()
        msg_strategy_info = "Running with {}".format(type(self.rtstr).__name__)
        msg = msg_broker_info + "\n" + msg_strategy_info
        self.log(msg, "run")
        self.rtstr.log_info()

        start = datetime.now()
        start = start.replace(second=0, microsecond=0)
        if self.interval == 24 * 60 * 60:  # 1d
            start = start.replace(hour=0, minute=0, second=0, microsecond=0)
            start += timedelta(days=1)
        elif self.interval == 60 * 60:  # 1h
            start = start.replace(minute=0, second=0, microsecond=0)
            start += timedelta(hours=1)
        elif self.interval == 60:  # 1m
            start = start.replace(second=0, microsecond=0)
            start += timedelta(minutes=1)
        elif self.interval == 1 \
                or self.interval is None:  # 1s
            start = start.replace(second=0, microsecond=0)
            start += timedelta(seconds=1)
        print("start time: ", start)
        msg = "start time: " + start.strftime("%Y/%m/%d %H:%M:%S")
        self.log(msg, "start time")
        start = datetime.timestamp(start)

        done = False
        while not done:
            print("[RUN] [CRAG] while step 1")
            now = time.time()
            sleeping_time = start - now
            # sleeping_time = 0 # CEDE DEBUG TO SKIP THE SLEEPING TIME
            if sleeping_time > 0:
                if self.safety_run:
                    start_minus_one_sec = datetime.timestamp(datetime.fromtimestamp(start) - timedelta(seconds=1))
                    while time.time() < start_minus_one_sec:
                        print("[RUN] [CRAG] while step 2")
                        step_result = self.safety_step()
                        print("[RUN] [CRAG] while step 3")
                        if not step_result:
                            print("safety_step result exit")
                            os._exit(0)
                        if self.rtstr.high_volatility.high_volatility_pause_status():
                            msg = "duration: " + str(self.rtstr.high_volatility.high_volatility_get_duration()) + "seconds"
                            self.log(msg, "PAUSE DUE HIGH VOLATILITY")
                            time.sleep(self.rtstr.high_volatility.high_volatility_get_duration())
                    while time.time() < start:
                        pass
                    print("[RUN] [CRAG] while step 4")
                else:
                    print("[RUN] [CRAG] while step 6")
                    time.sleep(sleeping_time)
                    print("[RUN] [CRAG] while step 7")
            else:
                # COMMENT CEDE REDUNDANT CODE
                if self.safety_run:
                    print("[RUN] [CRAG] while step 8")
                    step_result = self.safety_step()
                    print("[RUN] [CRAG] while step 9")
                    if self.interval != 1:  # 1s
                        self.log("safety run executed\n"
                                 + "warning : time elapsed for the step ({}) is greater than the interval ({})".format(sleeping_time, self.interval))
                    if not step_result:
                        os._exit(0)
                    print("[RUN] [CRAG] while step 10")
                    if self.rtstr.high_volatility.high_volatility_pause_status():
                        msg = "duration: " + str(self.rtstr.high_volatility.high_volatility_get_duration()) + "seconds"
                        self.log(msg, "PAUSE DUE HIGH VOLATILITY")
                        time.sleep(self.rtstr.high_volatility.high_volatility_get_duration())
                else:
                    print("[RUN] [CRAG] while step 11")
                    if self.interval != 1:  # 1s
                        self.log(
                            "warning : time elapsed for the step ({}) is greater than the interval ({})".format(
                                sleeping_time, self.interval))

            start = datetime.fromtimestamp(start)
            if self.interval == 24 * 60 * 60:  # 1d
                start += timedelta(days=1)
            elif self.interval == 60 * 60:  # 1h
                start += timedelta(hours=1)
            elif self.interval == 60:  # 1m
                start += timedelta(minutes=1)
            self.strategy_start_time = start
            start = datetime.timestamp(start)

            print("[RUN] [CRAG] while step 12")
            done = not self.step()
            if done:
                print("[RUN] [CRAG] while step 13")
                break
            print("[RUN] [CRAG] while step 14")

            self.broker.tick() # increment
            # self.backup() # backup for reboot

            if self.interval == 1:  # 1m # CEDE: CL to find cleaner solution
                start = datetime.now() + timedelta(seconds=2)
                start = datetime.timestamp(start)

        self.export_history(self.export_filename)

    def step(self):
        self.send_alive_notification()
        stop = self.monitoring.get_strategy_stop(self.rtstr.id)
        if stop:
            self.monitoring.send_strategy_stopped(self.rtstr.id)
            os._exit(0)
        prices_symbols, ds = self.get_ds_and_price_symbols()
        current_datetime = self.broker.get_current_datetime()
        self.rtstr.update(current_datetime, self.current_trades, self.broker.get_cash(), self.broker.get_cash_borrowed(), prices_symbols, False, self.final_datetime, self.broker.get_balance())

        if (self.rtstr.rtctrl.get_rtctrl_nb_symbols() > 0)\
                and (self.rtstr.position_recorder.get_total_position_engaged() == 0):
            # After reset PositionRecorder have to be updated
            print('reset PositionRecorder')
            self.rtstr.position_recorder.update_position_recorder(self.rtstr.rtctrl.get_rtctrl_lst_symbols())
        else:
            print('DEBUG - nb positions from rctctrl:          ', self.rtstr.rtctrl.get_rtctrl_nb_symbols())
            print('DEBUG - nb positions from PositionRecorder: ', self.rtstr.position_recorder.get_total_position_engaged())

        measure_time_fdp_start = datetime.now()

        nb_try = 0
        current_data_received = False

        # CEDE DEBUG
        print("request fdp [CRAG] [step]")
        while current_data_received != True:
            current_data = self.broker.get_current_data(ds)
            if current_data is None:
                print("current_data not received: ", nb_try)
                nb_try += 1
            else:
                current_data_received = True

        measure_time_fdp_end = datetime.now()
        print("measure time fdp:", measure_time_fdp_end - measure_time_fdp_start)

        if current_data is None:
            if not self.zero_print:
                print("[Crag] 💥 no current data")
            # self.force_sell_open_trade()
            self.rtstr.update(current_datetime, self.current_trades, self.broker.get_cash(), prices_symbols, True, self.final_datetime, self.broker.get_balance())
            return False

        self.rtstr.set_current_data(current_data)

        # portfolio_value = self.broker.get_portfolio_value()
        # portfolio_value = self.broker.get_wallet_equity()
        portfolio_value = self.broker.get_usdt_equity()
        current_date = self.broker.get_current_datetime("%Y/%m/%d %H:%M:%S")
        if portfolio_value < self.minimal_portfolio_value:
            self.minimal_portfolio_value = portfolio_value
            self.minimal_portfolio_date = current_date
            self.minimal_portfolio_variation = utils.get_variation(self.original_portfolio_value, self.minimal_portfolio_value)
        if portfolio_value > self.maximal_portfolio_value:
            self.maximal_portfolio_value = portfolio_value
            self.maximal_portfolio_date = current_date
            self.maximal_portfolio_variation = utils.get_variation(self.original_portfolio_value, self.maximal_portfolio_value)

        lst_stored_data_for_reboot = []
        msg = "start step current time : {}\n".format(current_date)
        if self.broker.is_reset_account():
            msg += "account reset\n"
            self.start_date_for_log = self.start_date
        else:
            msg += "account resumed\n"
            if self.start_date_from_resumed_data != "":
                self.start_date_for_log = self.start_date_from_resumed_data
            else:
                self.start_date_for_log = self.start_date
        msg += "original portfolio value : ${} ({})\n".format(utils.KeepNDecimals(self.original_portfolio_value, 2),
                                                              self.start_date_for_log)
        lst_stored_data_for_reboot.append(self.start_date_for_log)
        lst_stored_data_for_reboot.append(self.original_portfolio_value)
        variation_percent = utils.get_variation(self.original_portfolio_value, portfolio_value)
        msg += "current portfolio value : ${} / %{}\n".format(utils.KeepNDecimals(portfolio_value, 2),
                                                              utils.KeepNDecimals(variation_percent, 2))
        msg += "max value : ${} %{} ({})\n".format(utils.KeepNDecimals(self.maximal_portfolio_value, 2),
                                                   utils.KeepNDecimals(self.maximal_portfolio_variation, 2),
                                                   self.maximal_portfolio_date)
        lst_stored_data_for_reboot.append(self.maximal_portfolio_value)
        lst_stored_data_for_reboot.append(self.maximal_portfolio_date)
        msg += "min value : ${} %{} ({})\n".format(utils.KeepNDecimals(self.minimal_portfolio_value, 2),
                                                   utils.KeepNDecimals(self.minimal_portfolio_variation, 2),
                                                   self.minimal_portfolio_date)
        lst_stored_data_for_reboot.append(self.minimal_portfolio_value)
        lst_stored_data_for_reboot.append(self.minimal_portfolio_date)
        self.traces_trade_total_remaining = self.traces_trade_total_opened - self.traces_trade_total_closed
        msg += "transactions opened : {} / closed : {} / remaining open : {}\n".format(int(self.traces_trade_total_opened),
                                                                                       int(self.traces_trade_total_closed),
                                                                                       int(self.traces_trade_total_remaining))
        lst_stored_data_for_reboot.append(self.traces_trade_total_opened)
        lst_stored_data_for_reboot.append(self.traces_trade_total_closed)
        lst_stored_data_for_reboot.append(self.traces_trade_total_remaining)
        if self.traces_trade_total_closed == 0:
            win_rate = 0
        else:
            win_rate = 100 * self.traces_trade_positive / self.traces_trade_total_closed
        msg += "positive / negative trades : {} / {}\n".format(int(self.traces_trade_positive),
                                                               int(self.traces_trade_negative)
                                                               )
        lst_stored_data_for_reboot.append(self.traces_trade_positive)
        lst_stored_data_for_reboot.append(self.traces_trade_negative)
        self.save_reboot_data(lst_stored_data_for_reboot)
        msg += "win rate : %{}\n\n".format(utils.KeepNDecimals(win_rate, 2))

        if self.rtstr.rtctrl.get_rtctrl_nb_symbols() > 0:
            list_symbols = self.rtstr.rtctrl.get_rtctrl_lst_symbols()
            msg += "open position: {}\n".format(len(list_symbols))
            list_value = self.rtstr.rtctrl.get_rtctrl_lst_values()
            list_roi_dol = self.rtstr.rtctrl.get_rtctrl_lst_roi_dol()
            list_roi_percent = self.rtstr.rtctrl.get_rtctrl_lst_roi_percent()
            dict = {'symbol': list_symbols, 'value': list_value, 'roi_dol': list_roi_dol, 'roi_perc': list_roi_percent}
            df_position_at_start = pd.DataFrame(dict)
            df_position_at_start.sort_values(by=['roi_dol'], ascending=True, inplace=True)
            df_position_at_start["value"] = df_position_at_start["value"].round(2)
            df_position_at_start["roi_dol"] = df_position_at_start["roi_dol"].round(2)
            df_position_at_start["roi_perc"] = df_position_at_start["roi_perc"].round(2)
            positions_at_step_start = True
        else:
            msg += "no position\n"
            positions_at_step_start = False

        msg += "\nglobal unrealized PL = ${} / %{}\n".format(utils.KeepNDecimals(self.broker.get_global_unrealizedPL(), 2),
                                                             utils.KeepNDecimals(self.broker.get_global_unrealizedPL() * 100 / self.original_portfolio_value, 2) )
        msg += "current cash = ${}\n".format(utils.KeepNDecimals(self.broker.get_cash(), 2))
        usdt_equity = self.broker.get_usdt_equity()
        variation_percent = utils.get_variation(self.original_portfolio_value, usdt_equity)
        msg += "account equity = ${} / %{}".format(utils.KeepNDecimals(usdt_equity, 2),
                                                   utils.KeepNDecimals(variation_percent, 2))

        self.log(msg, "start step")

        if positions_at_step_start and len(df_position_at_start) >= 0:
            log_title = "step start with {} open position".format(len(df_position_at_start))
            self.log(df_position_at_start, log_title)

        if not self.zero_print:
            print("[Crag] ⌛")

        # execute trading
        self.trade()

        self.rtstr.log_current_info()

        unrealised_PL_long = 0
        unrealised_PL_short = 0
        lst_symbol_position = self.broker.get_lst_symbol_position()

        print("lst_symbol_position", lst_symbol_position)  # CEDE DEBUG

        if len(lst_symbol_position) > 0:
            msg = "end step with {} open position\n".format(len(lst_symbol_position))
            df_open_positions = pd.DataFrame(columns=["symbol", "pos_type", "size", "equity", "PL", "PL%"])
            for symbol in lst_symbol_position:
                symbol_equity = self.broker.get_symbol_usdtEquity(symbol)
                symbol_unrealizedPL = self.broker.get_symbol_unrealizedPL(symbol)
                if (symbol_equity - symbol_unrealizedPL) == 0:
                    symbol_unrealizedPL_percent = 0
                else:
                    symbol_unrealizedPL_percent = symbol_unrealizedPL * 100 / (symbol_equity - symbol_unrealizedPL)

                list_row = [self.broker.get_coin_from_symbol(symbol),
                            self.broker.get_symbol_holdSide(symbol).upper(),
                            utils.KeepNDecimals(self.broker.get_symbol_available(symbol), 2),
                            utils.KeepNDecimals(symbol_equity, 2),
                            utils.KeepNDecimals(symbol_unrealizedPL, 2),
                            utils.KeepNDecimals(symbol_unrealizedPL_percent, 2)
                            ]
                df_open_positions.loc[len(df_open_positions)] = list_row

                if self.broker.get_symbol_holdSide(symbol).upper() == "LONG":
                    unrealised_PL_long += symbol_unrealizedPL
                else:
                    unrealised_PL_short += symbol_unrealizedPL

            if len(df_open_positions) > 0:
                self.log(df_open_positions, msg)
            else:
                msg = "no position\n"
                self.log(msg, "no open position")
        else:
            msg = "no position\n"
            self.log(msg, "no open position")

        current_date = self.broker.get_current_datetime("%Y/%m/%d %H:%M:%S")
        msg = "end step current time : {}\n".format(current_date)
        msg += "account equity at start : $ {} ({})\n".format(utils.KeepNDecimals(self.original_portfolio_value, 2), self.start_date)
        msg += "unrealized PL LONG : ${}\n".format(utils.KeepNDecimals(unrealised_PL_long, 2))
        msg += "unrealized PL SHORT : ${}\n".format(utils.KeepNDecimals(unrealised_PL_short, 2))
        msg += "global unrealized PL : ${} / %{}\n".format(utils.KeepNDecimals(self.broker.get_global_unrealizedPL(), 2),
                                                           utils.KeepNDecimals(self.broker.get_global_unrealizedPL() * 100 / self.original_portfolio_value, 2))
        msg += "current cash = {}\n".format(utils.KeepNDecimals(self.broker.get_cash(), 2))
        usdt_equity = self.broker.get_usdt_equity()
        if self.previous_usdt_equity == 0:
            self.previous_usdt_equity = usdt_equity
        variation_percent = utils.get_variation(self.original_portfolio_value, usdt_equity)
        msg += "total SL TP: ${} / %{}\n".format(utils.KeepNDecimals(self.total_SL_TP, 2),
                                                 utils.KeepNDecimals(self.total_SL_TP_percent, 2))
        msg += "max drawdown: ${} / %{}\n".format(utils.KeepNDecimals(self.drawdown, 2),
                                                  utils.KeepNDecimals(self.actual_drawdown_percent, 2))
        msg += "account equity : ${} / %{}\n".format(utils.KeepNDecimals(usdt_equity, 2),
                                                   utils.KeepNDecimals(variation_percent, 2))
        variation_percent = utils.get_variation(self.previous_usdt_equity, usdt_equity)
        msg += "previous equity : ${} / ${} / %{}".format(utils.KeepNDecimals(self.previous_usdt_equity, 2),
                                                                   utils.KeepNDecimals(usdt_equity - self.previous_usdt_equity, 2),
                                                                   utils.KeepNDecimals(variation_percent, 2))
        self.previous_usdt_equity = usdt_equity
        self.log(msg, "end step")

        self.tradetraces.export()

        return not self.exit

    def export_history(self, target=None):
        self.broker.export_history(target)

    def _prepare_sell_trade_from_bought_trade(self, bought_trade, current_datetime):
        sell_trade = trade.Trade(current_datetime)
        sell_trade.type = self.rtstr.get_close_type(bought_trade.symbol)
        sell_trade.sell_id = bought_trade.id
        sell_trade.buying_price = bought_trade.buying_price
        sell_trade.buying_time = bought_trade.time
        # sell_trade.stimulus = df_selling_symbols["stimulus"][bought_trade.symbol]
        sell_trade.symbol = bought_trade.symbol
        sell_trade.symbol_price = self.broker.get_value(bought_trade.symbol)
        sell_trade.bought_gross_price = bought_trade.gross_price
        try:
            sell_trade.trace_id = bought_trade.id
        except:
            print("DEBUG TRACES ERROR - NO bought_trade.id")
            sell_trade.trace_id = 0
        sell_trade.commission = self.broker.get_commission(sell_trade.symbol)
        sell_trade.minsize = self.broker.get_minimum_size(sell_trade.symbol)

        sell_trade.cash_borrowed = bought_trade.cash_borrowed

        # Clear one trade position partialy:
        # sell_trade.gross_size = df_selling_symbols['size'][sell_trade.symbol]
        # Clear one trade position totaly
        # Option chosen... so far...
        sell_trade.gross_size = bought_trade.net_size

        if sell_trade.type == self.rtstr.close_long:
            sell_trade.gross_price = sell_trade.gross_size * sell_trade.symbol_price
            # sell_trade.gross_price = sell_trade.gross_size * (sell_trade.symbol_price + sell_trade.symbol_price - sell_trade.buying_price)
        elif sell_trade.type == self.rtstr.close_short:
            sell_trade.gross_price = sell_trade.gross_size * sell_trade.symbol_price  # (-) to be added un broker_execute_trade
            # sell_trade.gross_price = sell_trade.gross_size * (sell_trade.buying_price + sell_trade.buying_price - sell_trade.symbol_price)
        elif sell_trade.type == self.rtstr.no_position: # CEDE WORKAROUND to be fixed
            sell_trade.type = self.rtstr.close_long # CEDE WORKAROUND grid trading
            sell_trade.gross_price = sell_trade.gross_size * sell_trade.symbol_price

        sell_trade.net_price = sell_trade.gross_price - sell_trade.gross_price * self.broker.get_commission(bought_trade.symbol)
        sell_trade.net_size = round(sell_trade.net_price / sell_trade.symbol_price, 8)
        sell_trade.buying_fee = bought_trade.buying_fee
        sell_trade.selling_fee = sell_trade.gross_price - sell_trade.net_price
        sell_trade.roi = 100 * (sell_trade.net_price - bought_trade.gross_price) / bought_trade.gross_price
        # if sell_trade.type == self.rtstr.close_short:
        #    sell_trade.roi = -sell_trade.roi
        return sell_trade

    def trade(self):
        if not self.zero_print:
            print("[Crag.trade]")
        if self.cash == 0 and self.init_cash_value == 0:
            self.init_cash_value = self.broker.get_cash()
        self.cash = self.broker.get_cash()
        self.portfolio_value = self.rtstr.get_portfolio_value()
        current_datetime = self.broker.get_current_datetime()

        # sell symbols
        lst_symbols = [current_trade.symbol for current_trade in self.current_trades if self.rtstr.is_open_type(current_trade.type)]
        lst_symbols = list(set(lst_symbols))
        if (self.final_datetime and current_datetime >= self.final_datetime):
            # final step - force all the symbols to be sold
            df_selling_symbols = self.rtstr.get_df_forced_selling_symbols()
            self.exit = True
            self.flush_current_trade = True
        else:
            # identify symbols to sell
            df_selling_symbols = self.rtstr.get_df_selling_symbols(lst_symbols, self.rtstr.rtctrl.get_rtctrl_df_roi_sl_tp())

        list_symbols_to_sell = df_selling_symbols.symbol.to_list()
        df_selling_symbols.set_index("symbol", inplace=True)
        df_sell_performed = pd.DataFrame(columns=["symbol", "price", "roi%", "pos_type"])
        for current_trade in self.current_trades:
            if self.rtstr.is_open_type(current_trade.type) \
                    and current_trade.symbol in list_symbols_to_sell \
                    and self.flush_current_trade:
                sell_trade = self._prepare_sell_trade_from_bought_trade(current_trade, current_datetime)
                done = self.broker.execute_trade(sell_trade)
                if done:
                    self.sell_performed = True
                    current_trade.type = self.rtstr.get_close_type_and_close(current_trade.symbol)
                    self.cash = self.broker.get_cash()
                    sell_trade.cash = self.cash

                    self.traces_trade_total_closed += 1

                    self.tradetraces.set_sell(sell_trade.symbol, sell_trade.trace_id,
                                              sell_trade.symbol_price,
                                              sell_trade.gross_price,
                                              sell_trade.selling_fee,
                                              "CLOSURE")

                    self.current_trades.append(sell_trade)
                    df_sell_performed.loc[len(df_sell_performed.index)] = [sell_trade.symbol, round(sell_trade.gross_price, 2), round(sell_trade.roi, 2), sell_trade.type]

                    if sell_trade.roi < 0:
                        self.traces_trade_negative += 1
                    else:
                        self.traces_trade_positive += 1

        if self.sell_performed:
            if len(df_sell_performed) > 0:
                self.log(df_sell_performed, "symbol sold - performed")
            self.rtstr.update(current_datetime, self.current_trades, self.broker.get_cash(),  self.broker.get_cash_borrowed(), self.rtstr.rtctrl.prices_symbols, False, self.final_datetime, self.broker.get_balance())
            self.sell_performed = False

        # buy symbols
        df_buying_symbols = self.rtstr.get_df_buying_symbols()
        df_buying_symbols.set_index('symbol', inplace=True)
        df_buying_symbols.drop(df_buying_symbols[df_buying_symbols['size'] == 0].index, inplace=True)
        if current_datetime == self.final_datetime:
            df_buying_symbols.drop(df_buying_symbols.index, inplace=True)
        symbols_bought = {"symbol":[], "size":[], "percent":[], "gross_price":[], "pos_type": []}
        for symbol in df_buying_symbols.index.to_list():
            print("buying symbol: ", symbol)
            current_trade = trade.Trade(current_datetime)
            # current_trade.type = self.rtstr.get_open_type(symbol)
            current_trade.type = df_buying_symbols['pos_type'][symbol]
            current_trade.symbol = symbol

            current_trade.symbol_price = self.broker.get_value(symbol)
            current_trade.buying_price = current_trade.symbol_price

            current_trade.commission = self.broker.get_commission(current_trade.symbol)
            current_trade.minsize = self.broker.get_minimum_size(current_trade.symbol)

            current_trade.gross_size = df_buying_symbols["size"][symbol]  # Gross size
            current_trade.gross_price = current_trade.gross_size * current_trade.symbol_price

            # TMP HACK CEDE
            if abs(round(current_trade.gross_price, 4)) >= round(self.cash, 4):
                print("=========== > gross price do not fit cash value:")
                print("===========================================================================")
                print('cash', self.cash)
                print('gross_price', current_trade.gross_price)
                current_trade.gross_price = self.cash - self.cash * 0.1
                current_trade.gross_size = current_trade.gross_price / current_trade.buying_price
                print("===========================================================================")

            current_trade.net_price = round(current_trade.gross_price * (1 - current_trade.commission), 4)
            current_trade.net_size = round(current_trade.net_price / current_trade.symbol_price, 6)

            current_trade.buying_fee = abs(round(current_trade.gross_price - current_trade.net_price, 4))
            current_trade.profit_loss = -current_trade.buying_fee
            if current_trade.type == self.rtstr.open_long:
                current_trade.cash_borrowed = 0
            elif current_trade.type == self.rtstr.open_short:
                current_trade.cash_borrowed = current_trade.net_price

            if abs(current_trade.gross_price) <= self.cash:
                done = self.broker.execute_trade(current_trade)
                if done:
                    self.cash = self.broker.get_cash()
                    current_trade.cash = self.cash

                    self.traces_trade_total_opened += 1

                    self.tradetraces.add_new_entry(current_trade.symbol, current_trade.id, current_trade.clientOid,
                                                   current_trade.gross_size, current_trade.buying_price,
                                                   current_trade.bought_gross_price, current_trade.buying_fee)

                    self.current_trades.append(current_trade)

                    symbols_bought["symbol"].append(current_trade.symbol)
                    symbols_bought["size"].append(utils.KeepNDecimals(current_trade.gross_size))
                    symbols_bought["percent"].append(utils.KeepNDecimals(df_buying_symbols["percent"][current_trade.symbol]))
                    symbols_bought["gross_price"].append(utils.KeepNDecimals(current_trade.gross_price))
                    symbols_bought["pos_type"].append(df_buying_symbols["pos_type"][current_trade.symbol])
                else:
                    self.rtstr.open_position_failed(symbol)
            else:
                print("=========== > execute trade not actioned - gross price do not fit cash value:")
                print("=========== >abs(round(current_trade.gross_price, 4)) <= round(self.cash, 4)",
                      abs(round(current_trade.gross_price, 4)) <= round(self.cash, 4))
                print('=========== >current_trade.gross_price: ', current_trade.gross_price)
                print('=========== >self.cash: ', self.cash)
                self.rtstr.open_position_failed(symbol)

        df_symbols_bought = pd.DataFrame(symbols_bought)

        if not df_symbols_bought.empty:
            df_traces = df_symbols_bought.copy()
            self.log(df_traces, "symbols bought")

        if self.temp_debug:
            self.debug_trace_current_trades('end_trade', self.current_trades)

        # Clear the current_trades for optimization
        if self.rtstr.authorize_clear_current_trades() and len(self.current_trades) > 1:
            lst_buy_trades = []
            lst_buy_symbols_trades = []
            for current_trade in self.current_trades:
                if self.rtstr.is_open_type(current_trade.type):
                    lst_buy_trades.append(current_trade)
                    lst_buy_symbols_trades.append(current_trade.symbol)
            self.current_trades = lst_buy_trades

        if self.temp_debug:
            self.debug_trace_current_trades('clear    ', self.current_trades)

        # Merge the current_trades for optimization

        if self.rtstr.authorize_merge_current_trades() \
                and len(self.current_trades) > 1:
            lst_buy_trades_merged = []
            lst_buy_symbols_trades_unique = list(set(lst_buy_symbols_trades))
            if len(lst_buy_symbols_trades_unique) < len(lst_buy_symbols_trades):
                for position_type in self.rtstr.get_lst_opening_type():
                    for symbol in lst_buy_symbols_trades_unique:
                        # if lst_buy_symbols_trades.count(symbol) > 1:
                        if utils.count_symbols_with_position_type(self.current_trades, symbol, position_type) > 1:
                            merged_trades = self.merge_current_trades_from_symbol(self.current_trades, symbol, current_datetime, position_type)
                            lst_buy_trades_merged.append(merged_trades)
                        else:
                            for current_trade in self.current_trades:
                                if self.rtstr.is_open_type(current_trade.type)\
                                        and current_trade.symbol == symbol\
                                        and current_trade.type == position_type:
                                    # unique trade
                                    lst_buy_trades_merged.append(current_trade)
                self.current_trades = lst_buy_trades_merged

        if self.temp_debug:
            self.debug_trace_current_trades('merge    ', self.current_trades)

        if current_datetime == self.final_datetime or self.exit:
            self.rtstr.rtctrl.display_summary_info(True)
            self.exit = True

    def export_status(self):
        return self.broker.export_status()

    def backup(self):
        with open(self.backup_filename, 'wb') as file:
            # print("[crah::backup]", self.backup_filename)
            pickle.dump(self, file)

    def merge_current_trades_from_symbol(self, current_trades, symbol, current_datetime, position_type):
        lst_trades = []

        lst_current_trade_symbol_price = []
        lst_current_trade_buying_price = []
        lst_current_trade_commission = []
        lst_current_trade_gross_size = []
        lst_current_trade_gross_price = []
        lst_current_trade_net_price = []
        lst_current_trade_net_size = []
        lst_current_trade_buying_fee = []
        lst_current_trade_profit_loss = []

        for current_trade in current_trades:
            if current_trade.type == position_type and current_trade.symbol == symbol:
                lst_trades.append(current_trade)

                lst_current_trade_symbol_price.append(current_trade.symbol_price)
                lst_current_trade_buying_price.append(current_trade.buying_price)

                lst_current_trade_commission.append(current_trade.commission)

                lst_current_trade_gross_size.append(current_trade.gross_size)
                lst_current_trade_gross_price.append(current_trade.gross_price)

                lst_current_trade_net_price.append(current_trade.net_price)
                lst_current_trade_net_size.append(current_trade.net_size)

                lst_current_trade_buying_fee.append(current_trade.buying_fee)
                lst_current_trade_profit_loss.append(current_trade.profit_loss)

        merged_trade = trade.Trade(current_datetime)

        merged_trade.type = position_type
        merged_trade.symbol = symbol

        merged_trade.sell_id = ""
        merged_trade.stimulus = ""
        merged_trade.roi = ""
        merged_trade.selling_fee = ""

        merged_trade.buying_time = ""

        merged_trade.symbol_price = max(lst_current_trade_symbol_price)
        merged_trade.buying_price = max(lst_current_trade_buying_price)

        merged_trade.commission = sum(lst_current_trade_commission) / len(lst_current_trade_commission)

        merged_trade.gross_size = sum(lst_current_trade_gross_size)
        merged_trade.gross_price = sum(lst_current_trade_gross_price)

        merged_trade.net_price = sum(lst_current_trade_net_price)
        merged_trade.net_size = sum(lst_current_trade_net_size)

        merged_trade.buying_fee = sum(lst_current_trade_buying_fee)
        merged_trade.profit_loss = sum(lst_current_trade_profit_loss)

        merged_trade.portfolio_value = self.portfolio_value
        merged_trade.wallet_value = self.wallet_value
        merged_trade.wallet_roi = (self.wallet_value - self.init_cash_value) * 100 / self.init_cash_value

        self.traces_trade_total_opened = self.traces_trade_total_opened - len(lst_current_trade_symbol_price) + 1

        return merged_trade

    def debug_trace_current_trades(self, step_state, current_trades):
        iterration = 0
        msg = step_state
        for current_trade in current_trades:
            msg = msg + ' - trade: ' + str(iterration)
            iterration = iterration + 1
            msg = msg + ' symbol: ' + str(current_trade.symbol)
            msg = msg + ' type: ' + str(current_trade.type)
            msg = msg + ' price: ' + str(round(current_trade.net_price, 1))
            msg = msg + ' size: ' + str(round(current_trade.net_size, 4))
        print(msg)

    def create_directory(self, directory_path):
        if not os.path.exists(directory_path):
            os.makedirs(directory_path)
            print(f"Directory '{directory_path}' created successfully.")
        else:
            print(f"Directory '{directory_path}' already exists.")

    def save_df_csv_broker_current_state(self, output_dir, current_state):
        self.create_directory(output_dir)
        # Get the current date and time
        current_date = datetime.now()

        # Format the date as a string
        formatted_date = current_date.strftime("%Y%m%d_%H%M%S")

        df_current_states = current_state["open_orders"]
        df_open_positions = current_state["open_positions"]
        df_price = current_state["prices"]

        filename_df_current_states = f"data_{formatted_date}_df_current_states.csv"
        full_path = os.path.join(output_dir, filename_df_current_states)
        df_current_states.to_csv(full_path)

        filename_df_open_positions = f"data_{formatted_date}_df_open_positions.csv"
        full_path = os.path.join(output_dir, filename_df_open_positions)
        df_open_positions.to_csv(full_path)

        filename_df_price = f"data_{formatted_date}_df_price.csv"
        full_path = os.path.join(output_dir, filename_df_price)
        df_price.to_csv(full_path)


    def create_df_price(self, input_dir, len_df):
        filename = 'price_df_file.csv'
        filename = os.path.join(input_dir, filename)

        # Check if the file exists
        if not os.path.exists(filename):
            # Create a DataFrame
            frequency = 10
            cpt_values = np.arange(0, len_df+1)
            price_values = 0.6 + 0.1 * np.sin(cpt_values * (2 * np.pi * frequency / len_df))
            df = pd.DataFrame({'cpt': cpt_values, 'price': price_values})
            # Save the DataFrame to a CSV file
            df.to_csv(filename, index=False)

            debug_test = False
            if debug_test:
                plt.plot(df['cpt'], df['price'])
                plt.title('Sine Wave')
                plt.xlabel('cpt')
                plt.ylabel('price')
                plt.show()

        else:
            df = pd.read_csv(filename)
        return df

    def build_next_current_state_to_csv(self, input_dir, lst_orders_to_execute, broker_current_state, cpt):
        df_open_orders = broker_current_state["open_orders"]
        df_open_positions = broker_current_state["open_positions"]
        df_prices = broker_current_state["prices"]

        # Drop columns starting with 'Unamed'
        df_open_orders = df_open_orders.drop(df_open_orders.filter(like='Unnamed', axis=1).columns, axis=1)
        df_open_positions = df_open_positions.drop(df_open_positions.filter(like='Unnamed', axis=1).columns, axis=1)
        df_prices = df_prices.drop(df_prices.filter(like='Unnamed', axis=1).columns, axis=1)

        os.path.join(input_dir, "df_prices.csv")
        df_price = self.create_df_price(input_dir, 100)
        next_price = df_price.loc[df_price['cpt'] == cpt, 'price'].values[0]

        lst_position_to_drop = self.rtstr.get_grid_triggered_gridId(next_price)

        # Define a mapping for the 'side' values
        side_mapping = {
            'OPEN_LONG_ORDER': 'open_long',
            'OPEN_SHORT_ORDER': 'open_short',
            'CLOSE_LONG_ORDER': 'close_long',
            'CLOSE_SHORT_ORDER': 'close_short'
        }
        for order in lst_orders_to_execute:
            df_open_orders = df_open_orders[df_open_orders['gridId'] != order['grid_id']]

            side = side_mapping[order['type']]
            random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=10))
            new_row = {'symbol': order['symbol'],
                       'price': order['price'],
                       'side': side,
                       'leverage': 2,
                       'orderId': random_string,
                       'gridId': order['grid_id']
                       }
            df_open_orders = df_open_orders.append(new_row, ignore_index=True)

        price_changed = False
        df_count = df_open_orders.groupby(['symbol', 'side']).size().unstack(fill_value=0).reset_index()
        for symbol in df_open_orders['symbol'].tolist():
            if not price_changed:
                df_prices.loc[df_prices['symbols'] == symbol, 'values'] = next_price
                price_changed = True

            if 'open_long' in df_count.columns.tolist():
                open_long_count = df_count.loc[df_count['symbol'] == symbol, 'open_long'].values[0]
            else:
                open_long_count = 0
            if 'open_short' in df_count.columns.tolist():
                open_short_count = df_count.loc[df_count['symbol'] == symbol, 'open_short'].values[0]
            else:
                open_short_count = 0
            if 'close_long' in df_count.columns.tolist():
                close_long_count = df_count.loc[df_count['symbol'] == symbol, 'close_long'].values[0]
            else:
                close_long_count = 0
            if 'close_short' in df_count.columns.tolist():
                close_short_count = df_count.loc[df_count['symbol'] == symbol, 'close_short'].values[0]
            else:
                close_short_count = 0
            nb_total_opened = open_long_count + open_short_count
            nb_total_closed = close_long_count + close_short_count
            new_row = {'symbol': symbol,
                       'holdSide': None,
                       'leverage': None,
                       'marginCoin': None,
                       'available': None,
                       'total': nb_total_closed,
                       'usdtEquity': None,
                       'marketPrice': None,
                       'averageOpenPrice': None,
                       'achievedProfits': None,
                       'unrealizedPL': None,
                       'liquidationPrice': None
                       }
            df_open_positions = df_open_positions[df_open_positions['symbol'] != symbol]
            df_open_positions = df_open_positions.append(new_row, ignore_index=True)
        df_open_positions = df_open_positions[df_open_positions['total'] != 0]

        broker_next_current_state = {}
        broker_next_current_state["open_orders"] = df_open_orders
        broker_next_current_state["open_positions"] = df_open_positions
        broker_next_current_state["prices"] = df_prices

        self.save_current_state_to_csv(input_dir, cpt, broker_next_current_state)

    def save_current_state_to_csv(self, input_dir, cpt, broker_current_state):
        df_open_orders = broker_current_state["open_orders"]
        df_open_positions = broker_current_state["open_positions"]
        df_prices = broker_current_state["prices"]

        str_cpt = str(cpt)
        full_path = os.path.join(input_dir, "data_" + str_cpt + "_df_current_states.csv")
        df_open_orders.to_csv(full_path)

        full_path = os.path.join(input_dir, "data_" + str_cpt + "_df_open_positions.csv")
        df_open_positions.to_csv(full_path)

        full_path = os.path.join(input_dir, "data_" + str_cpt + "_df_price.csv")
        df_prices.to_csv(full_path)

    def get_current_state_from_csv(self, input_dir, cpt):
        str_cpt = str(cpt)
        full_path = os.path.join(input_dir, "data_" + str_cpt + "_df_current_states.csv")
        df_open_orders = pd.read_csv(full_path)

        full_path = os.path.join(input_dir, "data_" + str_cpt + "_df_open_positions.csv")
        df_open_positions = pd.read_csv(full_path)

        full_path = os.path.join(input_dir, "data_" + str_cpt + "_df_price.csv")
        df_prices = pd.read_csv(full_path)

        broker_current_state = {
            "open_orders": df_open_orders,
            "open_positions": df_open_positions,
            "prices": df_prices
        }
        return broker_current_state


    def udpate_strategy_with_broker_current_state_scenario(self, scenario_id):
        cpt = 0
        input_dir = "./grid_test/" + str(scenario_id) + "_scenario_test"
        while True:
            break_pt = 35
            if cpt == break_pt:
                print("cpt: ", cpt)
            self.start_time_grid_strategy = time.time()
            broker_current_state = self.get_current_state_from_csv(input_dir, cpt)
            lst_orders_to_execute = self.rtstr.set_broker_current_state(broker_current_state)
            print("output lst_orders_to_execute: ", lst_orders_to_execute)
            msg = self.rtstr.get_info_msg_status()
            if msg != None:
                current_datetime = datetime.today().strftime("%Y/%m/%d - %H:%M:%S")
                msg = current_datetime + "\n" + msg
                msg += "CPT: " + str(cpt) + "\n"
                usdt_equity = self.broker.get_usdt_equity()
                msg += "- USDT EQUITY: " + str(round(usdt_equity, 2)) + " - PNL: " + str(round(self.broker.get_global_unrealizedPL(), 2)) + "\n"
                msg += "AVERAGE RUN TIME: " + str(self.average_time_grid_strategy) + "s\n"
                self.log(msg, "GRID STATUS")
            end_time = time.time()
            self.iteration_times_grid_strategy.append(end_time - self.start_time_grid_strategy)
            self.average_time_grid_strategy = round(sum(self.iteration_times_grid_strategy) / len(self.iteration_times_grid_strategy), 2)
            print("GRID ITERATION AVERAGE TIME: " + str(self.average_time_grid_strategy) + " seconds")

            if cpt == break_pt:
                print("cpt: ", cpt)

            cpt += 1
            self.build_next_current_state_to_csv(input_dir, lst_orders_to_execute, broker_current_state, cpt)

    def udpate_strategy_with_broker_current_state(self):
        GRID_SCENARIO_ON = True
        SCENARIO_ID = 8
        if GRID_SCENARIO_ON:
            self.udpate_strategy_with_broker_current_state_scenario(SCENARIO_ID)
        else:
            self.udpate_strategy_with_broker_current_state_live()

    def udpate_strategy_with_broker_current_state_live(self):
        self.start_time_grid_strategy = time.time()
        if self.start_time_grid_strategy_init == None:
            self.start_time_grid_strategy_init = self.start_time_grid_strategy
            self.grid_iteration = 1
        else:
            self.grid_iteration += 1

        symbols = self.rtstr.lst_symbols
        broker_current_state = self.broker.get_current_state(symbols)
        if self.init_grid_position:
            self.init_grid_position = False
            self.rtstr.set_normalized_grid_price(self.broker.get_price_place_endstep(symbols))
            lst_orders_to_execute = self.rtstr.activate_grid(broker_current_state)
            lst_orders_to_execute = []
            self.broker.execute_orders(lst_orders_to_execute)
            self.broker.reset_current_postion(broker_current_state)
            broker_current_state = self.broker.get_current_state(symbols)

        lst_orders_to_execute = self.rtstr.set_broker_current_state(broker_current_state)

        msg = self.rtstr.get_info_msg_status()
        if msg != None:
            current_datetime = datetime.today().strftime("%Y/%m/%d - %H:%M:%S")
            msg = current_datetime + "\n" + msg
            usdt_equity = self.broker.get_usdt_equity()
            msg += "- USDT EQUITY: " + str(round(usdt_equity, 2)) \
                   + " - PNL: " + str(round(self.broker.get_global_unrealizedPL(), 2)) + "\n"
            msg += "AVERAGE RUN TIME: " + str(self.average_time_grid_strategy) + "s\n"
            self.log(msg, "GRID STATUS")

        if not self.zero_print:
            print("output lst_orders_to_execute: ", lst_orders_to_execute)

        self.broker.execute_orders(lst_orders_to_execute)

        end_time = time.time()
        self.iteration_times_grid_strategy.append(end_time - self.start_time_grid_strategy)
        self.iteration_times_grid_strategy = self.iteration_times_grid_strategy[-100:]
        self.average_time_grid_strategy = round(sum(self.iteration_times_grid_strategy) / len(self.iteration_times_grid_strategy), 2)
        self.average_time_grid_strategy_overall = round((end_time - self.start_time_grid_strategy_init) / self.grid_iteration, 2)

        if not self.zero_print:
            print("GRID ITERATION AVERAGE TIME: " + str(self.average_time_grid_strategy) + " seconds")
        # CEDE MEASURE RUN TIME IN ORDER TO BENCHMARK PC VS RASPBERRY
        print("GRID ITERATION AVERAGE TIME: " + str(self.average_time_grid_strategy) + " seconds")
        print("GRID ITERATION AVERAGE OVERALL TIME: " + str(self.average_time_grid_strategy_overall) + " seconds")
        print("CRAG TIME: " + str(round(self.average_time_grid_strategy_overall - self.average_time_grid_strategy, 4)) + " seconds - ITERATION: ", self.grid_iteration)

    def safety_step(self):
        usdt_equity = self.broker.get_usdt_equity()
        self.total_SL_TP = usdt_equity - self.original_portfolio_value
        if usdt_equity >= self.maximal_portfolio_value:
            self.maximal_portfolio_value = usdt_equity
            self.drawdown = 0
            self.actual_drawdown_percent = 0
        else:
            self.drawdown = usdt_equity - self.maximal_portfolio_value
            self.actual_drawdown_percent = self.drawdown * 100 / self.maximal_portfolio_value

        if self.original_portfolio_value == 0:
            self.total_SL_TP_percent = 0
        else:
            self.total_SL_TP_percent = self.total_SL_TP * 100 / self.original_portfolio_value

        if self.maximal_portfolio_value == 0:
            self.maximal_portfolio_value = max(usdt_equity, self.original_portfolio_value)
            self.actual_drawdown_percent = 0
        else:
            self.actual_drawdown_percent = self.drawdown * 100 / self.maximal_portfolio_value

        if self.rtstr.need_broker_current_state():
            # GRID TRADING STRATEGY
            self.udpate_strategy_with_broker_current_state()

        if self.rtstr.condition_for_global_SLTP(self.total_SL_TP_percent) \
                or self.rtstr.condition_for_global_trailer_TP(self.total_SL_TP_percent) \
                or self.rtstr.condition_for_global_trailer_SL(self.total_SL_TP_percent) \
                or self.rtstr.condition_for_max_drawdown_SL(self.actual_drawdown_percent):
            print('reset - global TP')
            print('total SL TP: $', self.total_SL_TP, "      ", self.total_SL_TP_percent, "%")
            print('max drawdown: $', self.drawdown, " - ", self.actual_drawdown_percent, "%")
            msg = "reset - total SL TP"
            msg += "total SL TP: ${} / %{}\n".format(utils.KeepNDecimals(self.total_SL_TP, 2),
                                                     utils.KeepNDecimals(self.total_SL_TP_percent, 2))
            msg += "max drawdown: ${} / %{}\n".format(utils.KeepNDecimals(self.drawdown, 2),
                                                      utils.KeepNDecimals(self.actual_drawdown_percent, 2))
            self.log(msg, "total SL TP")

            self.broker.execute_reset_account()
            return False

        if not self.rtstr.need_broker_current_state():
            # NOT AVAILABLE IN GRID TRADING STRATEGY
            lst_symbol_position = self.broker.get_lst_symbol_position()
            lst_symbol_for_closure = []
            for symbol in lst_symbol_position:
                symbol_equity = self.broker.get_symbol_usdtEquity(symbol)
                symbol_unrealizedPL = self.broker.get_symbol_unrealizedPL(symbol)
                if (symbol_equity - symbol_unrealizedPL) == 0:
                    symbol_unrealizedPL_percent = 0
                else:
                    symbol_unrealizedPL_percent = symbol_unrealizedPL * 100 / (symbol_equity - symbol_unrealizedPL)
                # print("symbol", symbol, "symbol_unrealizedPL: $", symbol_unrealizedPL, " - ", symbol_unrealizedPL_percent, "%") # DEBUG CEDE
                if self.rtstr.condition_for_SLTP(symbol_unrealizedPL_percent) \
                        or self.rtstr.condition_trailer_TP(self.broker._get_coin(symbol), symbol_unrealizedPL_percent)\
                        or self.rtstr.condition_trailer_SL(self.broker._get_coin(symbol), symbol_unrealizedPL_percent):
                    lst_symbol_for_closure.append(symbol)

            if self.rtstr.trigger_high_volatility_protection():
                BTC_price = self.broker.get_value('BTC')
                current_datetime = datetime.now()
                current_timestamp = datetime.timestamp(current_datetime)
                equity = self.broker.get_usdt_equity()
                # ['datetime', 'timestamp', 'symbol', 'pice', 'pct_BTC', 'equity', 'pct_equity']
                lst_record_volatility = [current_datetime, current_timestamp, 'BTC', BTC_price, 0, equity, 0]
                self.rtstr.set_high_volatility_protection_data(lst_record_volatility)
                if self.rtstr.high_volatility_protection_activation(self.actual_drawdown_percent):
                    print("DUMP POSITIONS DUE TO HIGH VOLATILITY")
                    lst_symbol_for_closure = self.broker.get_lst_symbol_position()
                    self.maximal_portfolio_value

            if len(lst_symbol_for_closure) > 0:
                current_datetime = datetime.today().strftime("%Y/%m/%d %H:%M:%S")
                for current_trade in self.current_trades:
                    symbol = self.broker._get_symbol(current_trade.symbol)
                    coin = current_trade.symbol
                    if self.rtstr.is_open_type(current_trade.type) and symbol in lst_symbol_for_closure:
                        print("SELL TRIGGERED SL TP: ", current_trade.symbol, " at: ", current_datetime) # DEBUG CEDE
                        msg = "SELL TRIGGERED SL TP: {} at: {}\n".format(current_trade.symbol, current_datetime)
                        sell_trade = self._prepare_sell_trade_from_bought_trade(current_trade,
                                                                                current_datetime)
                        done = self.broker.execute_trade(sell_trade)
                        if done:
                            print("SELL PERFORMED SL TP: ", current_trade.symbol, " at: ", current_datetime) # DEBUG CEDE
                            msg += "SELL PERFORMED SL TP"
                            self.log(msg, "SL TP PERFORMED")

                            self.sell_performed = True
                            current_trade.type = self.rtstr.get_close_type_and_close(current_trade.symbol)
                            self.cash = self.broker.get_cash()
                            sell_trade.cash = self.cash

                            self.tradetraces.set_sell(sell_trade.symbol, sell_trade.trace_id,
                                                      current_trade.symbol_price,
                                                      current_trade.gross_price,
                                                      current_trade.selling_fee,
                                                      "SL-TP")

                            if sell_trade.roi < 0:
                                self.traces_trade_negative += 1
                            else:
                                self.traces_trade_positive += 1

                            self.current_trades.append(sell_trade)
                        else:
                            print("SELL TRANSACTION FAILED SL TP: ", current_trade.symbol, " at: ", current_datetime)  # DEBUG CEDE
                            msg += "SELL TRANSACTION FAILED SL TP"
                            self.log(msg, "SL TP FAILED")

                        if self.sell_performed:
                            self.rtstr.update(current_datetime, self.current_trades, self.broker.get_cash(),
                                              self.broker.get_cash_borrowed(), self.rtstr.rtctrl.prices_symbols, False,
                                              self.final_datetime, self.broker.get_balance())
                            self.rtstr.set_symbol_trailer_tp_turned_off(coin)
                            self.sell_performed = False
        return True


    def get_current_trades_from_account(self):
        lst_symbol_position = self.broker.get_lst_symbol_position()
        current_open_trades = []
        for symbol in lst_symbol_position:
            current_datetime = datetime.today().strftime("%Y/%m/%d %H:%M:%S")
            current_trade = trade.Trade(current_datetime)
            current_trade.symbol = self.broker._get_coin(symbol)
            current_trade.buying_time = current_datetime
            current_trade.type = self.rtstr.get_bitget_position(current_trade.symbol, self.broker.get_symbol_holdSide(symbol))

            # current_trade.symbol_price = self.broker.get_value(symbol)
            current_trade.symbol_price = self.broker.get_symbol_marketPrice(symbol)
            current_trade.buying_price = self.broker.get_symbol_averageOpenPrice(symbol)

            current_trade.commission = self.broker.get_commission(current_trade.symbol)
            current_trade.minsize = self.broker.get_minimum_size(current_trade.symbol)

            current_trade.gross_size = self.broker.get_symbol_total(symbol)
            current_trade.gross_price = self.broker.get_symbol_usdtEquity(symbol)
            current_trade.bought_gross_price = current_trade.gross_price

            current_trade.net_price = self.broker.get_symbol_usdtEquity(symbol)
            current_trade.net_size = self.broker.get_symbol_available(symbol)

            if current_trade.net_size != current_trade.gross_size:
                print("warning size check: ", symbol, " - ", current_trade.net_size, " - ", current_trade.gross_size)

            current_trade.buying_fee = 0
            current_trade.profit_loss = 0

            if current_trade.type == self.rtstr.open_long:
                current_trade.cash_borrowed = 0
            elif current_trade.type == self.rtstr.open_short:
                current_trade.cash_borrowed = current_trade.net_price

            self.cash = self.broker.get_cash()
            current_trade.cash = self.cash
            current_trade.roi = self.broker.get_symbol_unrealizedPL(symbol)

            # Update traces
            self.traces_trade_total_opened = self.traces_trade_total_opened + 1

            current_open_trades.append(current_trade)

        return current_open_trades

    def get_ds_and_price_symbols(self):
        # update all the data
        # TODO : this call should be done once, during the initialization of the system
        ds = self.rtstr.get_data_description()

        if self.clear_unused_data:
            self.broker.check_data_description(ds)
            self.clear_unused_data = False
        try:
            prices_symbols = {symbol:self.broker.get_value(symbol) for symbol in ds.symbols}
        except:
            for symbol in ds.symbols:
                try:
                    self.broker.get_value(symbol)
                except:
                    print("symbol error: ", symbol)

        print('price: ', prices_symbols)

        return prices_symbols, ds

    def get_stored_data_list(self):
        return [
            "original start",             # OK
            "original portfolio value",   # OK
            "max value",            # OK
            "date max value",       # OK
            "min value",            # OK
            "date min value",       # OK
            "transactions opened",  # OK
            "closed",           # OK
            "remaining open",   # OK
            "positive trades",  # OK
            "negative trades"   # OK
        ]

    def save_reboot_data(self, lst_data):
        df = pd.DataFrame(columns=self.get_stored_data_list())
        df.loc[len(df)] = lst_data
        self.broker.save_reboot_data(df)

    def get_reboot_data(self):
        return self.broker.get_broker_boot_data()